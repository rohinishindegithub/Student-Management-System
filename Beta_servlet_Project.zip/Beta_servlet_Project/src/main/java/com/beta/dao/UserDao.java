package com.beta.dao;
//jdbc

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.beta.bean.Student;

public class UserDao {
	public static Connection getconnections()
	{
		Connection con=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/beta","root","ROOT");
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		return con;
	}
	public static int insert(Student ob)
	{
		int status=0;
		try
		{
			Connection con=UserDao.getconnections();
			String sql="insert into studentManagementSystem(id,name,email,phone,address) values (?,?,?,?,?)";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, ob.getId());
			ps.setString(2, ob.getName());
			ps.setString(3, ob.getEmail());
			ps.setString(4, ob.getPhone());
			ps.setString(5, ob.getAddress());
			
			status=ps.executeUpdate();
		
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		return status;
		
	}
	
	public static List<Student> fetch()
	{
		Connection con=UserDao.getconnections();
		String sql="select * from studentManagementSystem";
		List<Student> al=new ArrayList<>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				Student s=new Student();
				
				s.setId(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setEmail(rs.getString(3));
				s.setPhone(rs.getString(4));
				s.setAddress(rs.getString(5));
				
				al.add(s);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
		
	}
	public static int delete(int id)
	{
		int stutus=0;
		Connection con=UserDao.getconnections();
		String sql="delete from studentManagementSystem where id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			
			stutus=ps.executeUpdate();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stutus;
	}
	public static Student getStudentById(int id)
	{
		Student s=new Student();
		
		Connection con=UserDao.getconnections();
		String sql="select * from studentManagementSystem where id=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
				s.setId(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setEmail(rs.getString(3));
				s.setPhone(rs.getString(4));
				s.setAddress(rs.getString(5));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
	public static int update(Student s)
	{
		int status=0;
		Connection con=UserDao.getconnections();
		String sql="update studentManagementSystem set name=?,email=?,phone=?,address=? where id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getName());
			ps.setString(2, s.getEmail());
			ps.setString(3, s.getPhone());
			ps.setString(4, s.getAddress());
			ps.setInt(5, s.getId());
			
			status=ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
		
	}
}
