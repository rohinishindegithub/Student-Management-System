package com.beta.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beta.bean.Student;
import com.beta.dao.UserDao;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public StudentServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
	 int id=Integer.parseInt(request.getParameter("id"));
	 String name=request.getParameter("name");
	 String email=request.getParameter("email");
	 String phone=request.getParameter("phone");
	 String address=request.getParameter("address");
	 
	 Student ob=new Student();
	 
	 ob.setId(id);
	 ob.setName(name);
	 ob.setEmail(email);
	 ob.setPhone(phone);
	 ob.setAddress(address);
	 
	 System.out.println(ob);
	 
	 int stutus=UserDao.insert(ob);
	 
	 if(stutus!=0)
	 {
		 pw.println("<p> Data Insertation sucessfully </p>");
		 request.getRequestDispatcher("insert.html").include(request, response);
	 }
	 else
	 {
		 pw.println("<p> Data Insertation failed </p>");
	 }
	 
	 
	}

}
